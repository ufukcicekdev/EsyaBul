function getAddress() {
  const previousPageUrl = "/dashboard/addresses/";

  window.location.href = previousPageUrl;
}

function getPasswordProcess() {
  const previousPageUrl ="/dashboard/password/";

  window.location.href = previousPageUrl;
}


function getNotify() {
  const previousPageUrl ="/dashboard/notifications/";

  window.location.href = previousPageUrl;
}

function getProfile() {
  const previousPageUrl ="/dashboard/profile/";

  window.location.href = previousPageUrl;
}
